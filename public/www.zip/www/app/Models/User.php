<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Illuminate\Support\Str;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'api_key',
        'subscription_tier',
        'max_accounts',
        'is_active',
	'is_admin',
	'last_login_at',
	'display_currency',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
	'last_login_at' => 'datetime',
        'password' => 'hashed',
        'is_active' => 'boolean',
	'is_admin' => 'boolean', 
        'max_accounts' => 'integer',
    ];

/**
 * Boot the model
 */
protected static function boot()
{
    parent::boot();
    
    // Auto-generate API key when creating a new user
    static::creating(function ($user) {
        if (empty($user->api_key)) {
            $user->api_key = self::generateApiKey();
        }
    });
}

    // Relationships
    public function tradingAccounts()
    {
        return $this->hasMany(TradingAccount::class);
    }

    public function activeTradingAccounts()
    {
        return $this->hasMany(TradingAccount::class)->where('is_active', true);
    }

    // Helper methods
    public static function generateApiKey()
    {
        return 'tvsr_' . Str::random(64);
    }

    public function canAddAccount()
    {
        return $this->tradingAccounts()->count() < $this->max_accounts;
    }

    public function isSubscribed()
    {
        return $this->subscription_tier !== 'free';
    }

/**
 * Regenerate API key
 */
public function regenerateApiKey()
{
    $this->api_key = self::generateApiKey();
    $this->save();
    return $this->api_key;
}

/**
 * Check if user can add more accounts
 */
public function canAddMoreAccounts()
{
    return $this->tradingAccounts()->count() < $this->max_accounts;
}

/**
 * Get account limit info
 */
public function getAccountLimitInfo()
{
    $current = $this->tradingAccounts()->count();
    $max = $this->max_accounts;
    
    return [
        'current' => $current,
        'max' => $max,
        'remaining' => max(0, $max - $current),
        'can_add' => $current < $max,
    ];
}

}
