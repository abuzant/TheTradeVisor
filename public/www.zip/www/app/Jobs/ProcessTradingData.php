<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\TradingAccount;
use App\Models\Position;
use App\Models\Order;
use App\Models\Deal;
use Carbon\Carbon;
use App\Models\SymbolMapping;


class ProcessTradingData implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 300; // 5 minutes
    public $tries = 3;

    protected $data;
    protected $filename;

    public function __construct($data, $filename)
    {
        $this->data = $data;
        $this->filename = $filename;
    }

    public function handle(): void
    {
        try {
            DB::beginTransaction();

            $userId = $this->data['user_id'];
            $clientIp = $this->data['client_ip'];
            $isFirstRun = $this->data['meta']['is_first_run'] ?? false;

            Log::info('Processing trading data', [
                'user_id' => $userId,
                'is_first_run' => $isFirstRun,
                'file' => $this->filename
            ]);

            // 1. Process Account Information
            $tradingAccount = $this->processAccount($userId, $clientIp);

            // 2. Process Open Positions
            if (isset($this->data['positions']) && is_array($this->data['positions'])) {
                $this->processPositions($tradingAccount, $this->data['positions']);
            }

            // 3. Process Pending Orders
            if (isset($this->data['orders']) && is_array($this->data['orders'])) {
                $this->processOrders($tradingAccount, $this->data['orders']);
            }

            // 4. Process History/Deals
            if (isset($this->data['history']) && is_array($this->data['history'])) {
                $this->processDeals($tradingAccount, $this->data['history']);
            }

            DB::commit();

            Log::info('Successfully processed trading data', [
                'trading_account_id' => $tradingAccount->id,
                'user_id' => $userId
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            
            Log::error('Failed to process trading data', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'file' => $this->filename
            ]);

            throw $e;
        }
    }

    /**/
/**
 * Process account information
 */
/**
 * Process account information
 */
protected function processAccount($userId, $clientIp)
{
    $accountData = $this->data['account'];
    $meta = $this->data['meta'];


    // Detect account type
    $accountTypeCode = $accountData['account_type'] ?? 0;
    $accountType = $this->getAccountType($accountTypeCode);
    
    // REJECT DEMO ACCOUNTS
    if ($accountType === 'demo' || $accountType === 'contest') {
        Log::warning('Demo/Contest account rejected', [
            'account_number' => $accountData['account_number'] ?? $accountData['account_hash'] ?? 'unknown',
            'broker' => $accountData['broker'],
            'type' => $accountType,
        ]);
        
        throw new \Exception('Demo and contest accounts are not allowed. Please connect a real trading account.');
    }

    // GeoIP disabled - we'll add it later
    $country = null;
    $city = null;
    $timezone = null;

    // Extract account details with fallbacks
    $accountNumber = $accountData['account_number'] ?? null;
    $accountHash = $accountData['account_hash'] ?? null;
    $brokerServer = $accountData['server'] ?? 'Unknown';
    $brokerName = $accountData['broker'] ?? 'Unknown';

    // Find existing account or create new one
    $tradingAccount = TradingAccount::where('user_id', $userId)
        ->where('broker_server', $brokerServer)
        ->where(function($query) use ($accountNumber, $accountHash) {
            if ($accountNumber) {
                $query->where('account_number', $accountNumber);
            } elseif ($accountHash) {
                $query->where('account_hash', $accountHash);
            }
        })
        ->first();

    // If not found, create new account
    if (!$tradingAccount) {
        $tradingAccount = TradingAccount::create([
            'user_id' => $userId,
            'account_uuid' => TradingAccount::generateUuid(),
            'account_number' => $accountNumber,
            'account_hash' => $accountHash,
            'broker_server' => $brokerServer,
            'broker_name' => $brokerName,
	    'account_type' => $accountType,
            'account_name' => $accountData['name'] ?? null,
            'account_currency' => $accountData['currency'] ?? 'USD',
            'leverage' => $accountData['leverage'] ?? 1,
            'balance' => $accountData['balance'] ?? 0,
            'equity' => $accountData['equity'] ?? 0,
            'margin' => $accountData['margin'] ?? 0,
            'free_margin' => $accountData['free_margin'] ?? 0,
            'margin_level' => $accountData['margin_level'] ?? null,
            'profit' => $accountData['profit'] ?? 0,
            'credit' => $accountData['credit'] ?? 0,
            'trade_allowed' => $accountData['trade_allowed'] ?? true,
            'trade_expert' => $accountData['trade_expert'] ?? true,
            'last_seen_ip' => $clientIp,
            'detected_country' => $country,
            'detected_city' => $city,
            'detected_timezone' => $timezone,
            'last_sync_at' => now(),
            'is_active' => true,
        ]);

        Log::info('Created new trading account', [
            'account_id' => $tradingAccount->id,
            'broker' => $brokerName,
        ]);
    } else {
        // Update existing account
        $tradingAccount->update([
            'broker_name' => $brokerName,
	    'account_type' => $accountType,
            'account_name' => $accountData['name'] ?? null,
            'account_currency' => $accountData['currency'] ?? 'USD',
            'leverage' => $accountData['leverage'] ?? 1,
            'balance' => $accountData['balance'] ?? 0,
            'equity' => $accountData['equity'] ?? 0,
            'margin' => $accountData['margin'] ?? 0,
            'free_margin' => $accountData['free_margin'] ?? 0,
            'margin_level' => $accountData['margin_level'] ?? null,
            'profit' => $accountData['profit'] ?? 0,
            'credit' => $accountData['credit'] ?? 0,
            'trade_allowed' => $accountData['trade_allowed'] ?? true,
            'trade_expert' => $accountData['trade_expert'] ?? true,
            'last_seen_ip' => $clientIp,
            'detected_country' => $country,
            'detected_city' => $city,
            'detected_timezone' => $timezone,
            'last_sync_at' => now(),
            'is_active' => true,
        ]);

        Log::info('Updated existing trading account', [
            'account_id' => $tradingAccount->id,
        ]);
    }

    return $tradingAccount;
}






/**
 * Process open positions
 */
protected function processPositions($tradingAccount, $positions)
{
    // Mark all positions as closed first
    Position::where('trading_account_id', $tradingAccount->id)
        ->where('is_open', true)
        ->update(['is_open' => false]);

    foreach ($positions as $positionData) {

    if (empty($positionData['symbol'])) {
        Log::warning('Position with missing symbol skipped', [
            'ticket' => $positionData['ticket'] ?? 'unknown'
        ]);
        continue;
    }

        // Auto-detect and normalize symbol
        SymbolMapping::normalize($positionData['symbol']);
        
        Position::updateOrCreate(
            [
                'trading_account_id' => $tradingAccount->id,
                'ticket' => $positionData['ticket'],
            ],
            [
                'symbol' => $positionData['symbol'],
                'comment' => $positionData['comment'] ?? null,
                'external_id' => $positionData['external_id'] ?? null,
                'type' => $positionData['type'],
                'reason' => $positionData['reason'] ?? 'unknown',
                'volume' => $positionData['volume'],
                'open_price' => $positionData['open_price'],
                'current_price' => $positionData['current_price'],
                'sl' => $positionData['sl'] ?? null,
                'tp' => $positionData['tp'] ?? null,
                'profit' => $positionData['profit'],
                'swap' => $positionData['swap'],
                'commission' => $positionData['commission'],
                'open_time' => $this->parseDateTime($positionData['open_time']),
                'update_time' => $this->parseDateTime($positionData['update_time'] ?? null),
                'magic' => $positionData['magic'] ?? 0,
                'identifier' => $positionData['identifier'] ?? null,
                'is_open' => true,
            ]
        );
    }

    Log::info('Processed positions', [
        'account_id' => $tradingAccount->id,
        'count' => count($positions)
    ]);
}

/**
 * Process pending orders
 */
protected function processOrders($tradingAccount, $orders)
{
    // Mark all orders as inactive first
    Order::where('trading_account_id', $tradingAccount->id)
        ->where('is_active', true)
        ->update(['is_active' => false]);

    foreach ($orders as $orderData) {

    // Skip if symbol is missing
    if (empty($orderData['symbol'])) {
        Log::warning('Order with missing symbol skipped', [
            'ticket' => $orderData['ticket'] ?? 'unknown'
        ]);
        continue;
    }


        // Auto-detect and normalize symbol
        SymbolMapping::normalize($orderData['symbol']);
        
        Order::updateOrCreate(
            [
                'trading_account_id' => $tradingAccount->id,
                'ticket' => $orderData['ticket'],
            ],
            [
                'symbol' => $orderData['symbol'],
                'comment' => $orderData['comment'] ?? null,
                'external_id' => $orderData['external_id'] ?? null,
                'type' => $orderData['type'],
                'state' => $orderData['state'] ?? null,
                'reason' => $orderData['reason'] ?? 'unknown',
                'volume_initial' => $orderData['volume_initial'],
                'volume_current' => $orderData['volume_current'],
                'price_open' => $orderData['price_open'],
                'price_current' => $orderData['price_current'] ?? null,
                'price_stoplimit' => $orderData['price_stoplimit'] ?? null,
                'sl' => $orderData['sl'] ?? null,
                'tp' => $orderData['tp'] ?? null,
                'time_setup' => $this->parseDateTime($orderData['time_setup']),
                'time_setup_msc' => $orderData['time_setup_msc'] ?? null,
                'time_done' => $this->parseDateTime($orderData['time_done'] ?? null),
                'time_done_msc' => $orderData['time_done_msc'] ?? null,
                'expiration' => $this->parseDateTime($orderData['expiration'] ?? null),
                'position_id' => $orderData['position_id'] ?? null,
                'position_by_id' => $orderData['position_by_id'] ?? null,
                'magic' => $orderData['magic'] ?? 0,
                'is_active' => true,
            ]
        );
    }

    Log::info('Processed orders', [
        'account_id' => $tradingAccount->id,
        'count' => count($orders)
    ]);
}

/**
 * Process closed deals/history
 */
protected function processDeals($tradingAccount, $deals)
{
    $newDealsCount = 0;

    foreach ($deals as $dealData) {

    // Skip if symbol is missing
    if (empty($dealData['symbol'])) {
        Log::warning('Deal with missing symbol skipped', [
            'ticket' => $dealData['ticket'] ?? 'unknown'
        ]);
        continue;
    }
        // Auto-detect and normalize symbol
        SymbolMapping::normalize($dealData['symbol']);
        
        // Check if deal already exists (avoid duplicates)
        $exists = Deal::where('trading_account_id', $tradingAccount->id)
            ->where('ticket', $dealData['ticket'])
            ->exists();

        if (!$exists) {
            Deal::create([
                'trading_account_id' => $tradingAccount->id,
                'ticket' => $dealData['ticket'],
                'order_id' => $dealData['order'] ?? null,
                'position_id' => $dealData['position_id'] ?? null,
                'symbol' => $dealData['symbol'],
                'comment' => $dealData['comment'] ?? null,
                'external_id' => $dealData['external_id'] ?? null,
                'type' => $dealData['type'],
                'entry' => $dealData['entry'] ?? 'unknown',
                'reason' => $dealData['reason'] ?? 'unknown',
                'volume' => $dealData['volume'],
                'price' => $dealData['price'],
                'profit' => $dealData['profit'],
                'swap' => $dealData['swap'],
                'commission' => $dealData['commission'],
                'fee' => $dealData['fee'] ?? 0,
                'time' => $this->parseDateTime($dealData['time']),
                'time_msc' => $dealData['time_msc'] ?? null,
                'magic' => $dealData['magic'] ?? 0,
            ]);

            $newDealsCount++;
        }
    }

    Log::info('Processed deals', [
        'account_id' => $tradingAccount->id,
        'total_received' => count($deals),
        'new_deals' => $newDealsCount
    ]);
}



    /**
     * Parse datetime string to Carbon instance
     */
	protected function parseDateTime($dateString)
	{
	    // Handle null or empty values
	    if (empty($dateString) || $dateString === '1970-01-01 00:00:00' || $dateString === 0) {
	        return null;
	    }
	
	    try {
	        // If it's a numeric timestamp (MT5 sometimes sends these)
	        if (is_numeric($dateString) && $dateString > 1000000000) {
	            return Carbon::createFromTimestamp($dateString);
	        }
	        
	        // If it's a small number, might be invalid
	        if (is_numeric($dateString) && $dateString < 1000000000) {
	            return now(); // Fallback for invalid timestamps
	        }
	        
	        // MT5 uses format: 2025.10.28 23:59:32 (dots instead of dashes)
	        // Convert dots to dashes
	        if (is_string($dateString) && strpos($dateString, '.') !== false) {
	            $dateString = str_replace('.', '-', $dateString);
	        }
	        
	        // Try to parse as datetime string
	        $parsed = Carbon::parse($dateString);
	        
	        // Verify it's a valid date (not 1970)
	        if ($parsed->year < 2000) {
	            return now(); // Return current time for invalid dates
	        }
	        
	        return $parsed;
	        
	    } catch (\Exception $e) {
	        Log::warning('Failed to parse datetime', [
	            'value' => $dateString,
	            'type' => gettype($dateString),
	            'error' => $e->getMessage()
	        ]);
	        
	        // Return current time as fallback to avoid NULL constraint violation
	        return now();
	    }
		}


    /**
     * Handle job failure
     */
    public function failed(\Throwable $exception)
    {
        Log::error('ProcessTradingData job failed', [
            'error' => $exception->getMessage(),
            'file' => $this->filename
        ]);
    }


	/**
	 * Get account type from code
	 */
	protected function getAccountType($code)
	{
	    switch ($code) {
	        case 0:
	            return 'real';
	        case 1:
	            return 'demo';
	        case 2:
	            return 'contest';
	        default:
	            return 'unknown';
	    }
	}


}
