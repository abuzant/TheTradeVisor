<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\TradingAccount;
use App\Models\Position;
use App\Models\Deal;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{

public function index()
{
	    $stats = [
	        'total_users' => User::count(),
	        'admin_users' => User::where('is_admin', true)->count(),
	        'total_accounts' => TradingAccount::count(),
	        'active_accounts' => TradingAccount::where('is_active', true)->count(),
	        'total_positions' => Position::where('is_open', true)->count(),
	        'total_trades_today' => Deal::whereDate('time', today())->count(),
	        'total_volume_today' => Deal::whereDate('time', today())->sum('volume'),
	    ];
	    
	    // Remove limit() when using paginate()
	    		//	$recentUsers = User::latest()->paginate(10, ['*'], 'users_page');
	    		//	$recentAccounts = TradingAccount::with('user')->latest('last_sync_at')->paginate(10, ['*'], 'accounts_page');

	
	    // FIXED: Use paginate() properly - these will be paginated results
	    $recentUsers = User::latest()->paginate(10, ['*'], 'users_page');
	    
	    $recentAccounts = TradingAccount::with('user')
	        ->latest('last_sync_at')
	        ->paginate(10, ['*'], 'accounts_page');

	    
	    return view('admin.dashboard', compact('stats', 'recentUsers', 'recentAccounts'));
	}


}
