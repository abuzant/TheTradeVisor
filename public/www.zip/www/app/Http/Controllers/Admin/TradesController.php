<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Deal;
use App\Models\TradingAccount;
use App\Models\User;
use App\Models\SymbolMapping;
use Carbon\Carbon;

class TradesController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->get('search');
        $userId = $request->get('user_id');
        $accountId = $request->get('account');
        $symbol = $request->get('symbol');
        $type = $request->get('type', 'all');
        $dateFrom = $request->get('date_from');
        $dateTo = $request->get('date_to');
        $perPage = $request->get('per_page', 50);

        $query = Deal::with(['tradingAccount.user']);

	// Default: exclude balance operations unless specifically requested
	if (!$request->has('show_balance') || !$request->get('show_balance')) {
	    $query->whereNotNull('symbol')
	          ->where('symbol', '!=', '')
	          ->where('symbol', '!=', 'UNKNOWN');
	}

        // Search
        if ($search) {
            $query->where(function($q) use ($search) {
                $q->where('symbol', 'like', "%{$search}%")
                  ->orWhere('ticket', 'like', "%{$search}%")
                  ->orWhereHas('tradingAccount.user', function($q) use ($search) {
                      $q->where('name', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%");
                  });
            });
        }

        // Filter by user
        if ($userId) {
            $query->whereHas('tradingAccount', function($q) use ($userId) {
                $q->where('user_id', $userId);
            });
        }

        // Filter by account
        if ($accountId) {
            $query->where('trading_account_id', $accountId);
        }

        // Filter by symbol (handle both raw and normalized)
        if ($symbol) {
            // Find all raw symbols that match this normalized symbol
            $rawSymbols = SymbolMapping::where('normalized_symbol', $symbol)->pluck('raw_symbol');

            if ($rawSymbols->isNotEmpty()) {
                $query->whereIn('symbol', $rawSymbols);
            } else {
                // Fallback to direct match
                $query->where('symbol', $symbol);
            }
        }

        // Filter by type
        if ($type && $type !== 'all') {
            switch ($type) {
                case 'buy':
                    $query->where('type', 'like', 'buy%');
                    break;
                case 'sell':
                    $query->where('type', 'like', 'sell%');
                    break;
                case 'trades':
                    // Only show buy and sell operations
                    $query->where(function($q) {
                        $q->where('type', 'like', 'buy%')
                          ->orWhere('type', 'like', 'sell%');
                    });
                    break;
                case 'cashier':
                    $query->whereIn('type', ['balance', 'credit']);
                    break;
                case 'fees':
                    $query->where('type', 'commission');
                    break;
                case 'swaps':
                    $query->where('type', 'swap');
                    break;
            }
        }

        // Date range filter
        if ($dateFrom) {
            $query->where('time', '>=', $dateFrom . ' 00:00:00');
        }
        if ($dateTo) {
            $query->where('time', '<=', $dateTo . ' 23:59:59');
        }

        // Clone query for totals calculation BEFORE pagination
        $totalsQuery = clone $query;

        // Paginate with query string preservation
        $deals = $query->orderBy('time', 'desc')->paginate($perPage)->withQueryString();

        // Get filter options - FIXED: Get from symbol_mappings table
        $symbols = SymbolMapping::select('normalized_symbol')
            ->distinct()
            ->orderBy('normalized_symbol')
            ->pluck('normalized_symbol');

        // If no mappings exist yet, fallback to raw symbols from deals
        if ($symbols->isEmpty()) {
            $symbols = Deal::select('symbol')
                ->distinct()
                ->orderBy('symbol')
                ->pluck('symbol');
        }

        $users = User::orderBy('name')->get();

        // Calculate totals from the filtered query
        $totals = [
            'totalProfit' => $totalsQuery->sum('profit'),
            'totalCommission' => $totalsQuery->sum('commission'),
            'totalFees' => $totalsQuery->sum('fee'),
            'totalSwap' => $totalsQuery->sum('swap'),
            'totalVolume' => $totalsQuery->sum('volume'),
            'tradeCount' => $totalsQuery->count(),
        ];

        // Stats for dashboard cards
        $stats = [
            'total' => Deal::count(),
            'today' => Deal::whereDate('time', Carbon::today())->count(),
            'week' => Deal::whereBetween('time', [Carbon::now()->startOfWeek(), Carbon::now()->endOfWeek()])->count(),
            'active_users' => User::where('is_active', true)->count(),
        ];

        return view('admin.trades.index', compact(
            'deals',
            'symbols',
            'users',
            'search',
            'userId',
            'accountId',
            'symbol',
            'type',
            'dateFrom',
            'dateTo',
            'perPage',
            'totals',
            'stats'
        ));
    }
}
