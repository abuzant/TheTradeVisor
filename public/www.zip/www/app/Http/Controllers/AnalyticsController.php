<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TradingAccount;
use App\Models\Position;
use App\Models\Order;
use App\Models\Deal;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

class AnalyticsController extends Controller
{
    /**
     * Global analytics dashboard
     */
    public function index(Request $request)
    {
        // User must have at least one active account to view global analytics
        $user = $request->user();
        
        if ($user->tradingAccounts()->where('is_active', true)->count() === 0) {
            return view('analytics.locked');
        }
        
        // Cache analytics for 5 minutes
        $analytics = Cache::remember('global_analytics', 300, function () {
            return [
                'overview' => $this->getOverviewStats(),
                'popular_pairs' => $this->getPopularPairs(),
                'trading_by_hour' => $this->getTradingByHour(),
                'regional_activity' => $this->getRegionalActivity(),
                'broker_distribution' => $this->getBrokerDistribution(),
                'sentiment' => $this->getMarketSentiment(),
                'top_performers' => $this->getTopPerformers(),
            ];
        });
        
        return view('analytics.index', compact('analytics'));
    }
    
    /**
     * Get overview statistics
     */
    private function getOverviewStats()
    {
	    return [
	        'total_traders' => TradingAccount::distinct('user_id')->count('user_id'),
	        'active_accounts' => TradingAccount::where('is_active', true)->count(),
	        'total_brokers' => TradingAccount::distinct('broker_name')->count('broker_name'),
	        'open_positions' => Position::where('is_open', true)->count(),
	        'total_volume_today' => Deal::whereNotNull('symbol')           // ADD THIS
	                                     ->where('symbol', '!=', '')        // ADD THIS
	                                     ->whereDate('time', today())
	                                     ->sum('volume'),
	        'trades_today' => Deal::whereNotNull('symbol')                 // ADD THIS
	                              ->where('symbol', '!=', '')              // ADD THIS
	                              ->whereDate('time', today())
	                              ->count(),
	        'countries' => TradingAccount::whereNotNull('detected_country')->distinct('detected_country')->count('detected_country'),
	    ];
    }
    
    /**
     * Get most popular trading pairs
     */
    private function getPopularPairs()
    {
        return Deal::select('symbol', DB::raw('COUNT(*) as trades'), DB::raw('SUM(volume) as total_volume'))
            ->whereNotNull('symbol')
            ->where('symbol', '!=', '')
            ->where('symbol', '!=', 'UNKNOWN')
            ->whereDate('time', '>=', now()->subDays(7))
            ->groupBy('symbol')
            ->orderBy('trades', 'desc')
            ->limit(10)
            ->get()
            ->map(function($item) {
                return [
                    'symbol' => $item->normalized_symbol,
                    'trades' => $item->trades,
                    'volume' => round($item->total_volume, 2),
                ];
            });
    }
    
    /**
     * Get trading activity by hour (UTC)
     */
    private function getTradingByHour()
    {
        $data = Deal::select(DB::raw('EXTRACT(HOUR FROM time) as hour'), DB::raw('COUNT(*) as count'))
            ->whereNotNull('symbol')           // ADD THIS
            ->where('symbol', '!=', '')        // ADD THIS            
	    ->whereDate('time', '>=', now()->subDays(7))
            ->groupBy('hour')
            ->orderBy('hour')
            ->get()
            ->pluck('count', 'hour');
        
        $result = [];
        for ($i = 0; $i < 24; $i++) {
            $result[] = [
                'hour' => str_pad($i, 2, '0', STR_PAD_LEFT) . ':00',
                'trades' => $data->get($i, 0),
            ];
        }
        
        return $result;
    }
    
    /**
     * Get regional trading activity
     */
    private function getRegionalActivity()
    {
        return TradingAccount::select('detected_country', DB::raw('COUNT(*) as accounts'), DB::raw('SUM(balance) as total_balance'))
            ->whereNotNull('detected_country')
            ->where('is_active', true)
            ->groupBy('detected_country')
            ->orderBy('accounts', 'desc')
            ->limit(10)
            ->get()
            ->map(function($item) {
                return [
                    'country' => $item->detected_country,
                    'accounts' => $item->accounts,
                    'balance' => round($item->total_balance, 2),
                ];
            });
    }
    
    /**
     * Get broker distribution
     */
    private function getBrokerDistribution()
    {
        return TradingAccount::select('broker_name', DB::raw('COUNT(*) as accounts'))
            ->where('is_active', true)
            ->groupBy('broker_name')
            ->orderBy('accounts', 'desc')
            ->limit(8)
            ->get();
    }
    
    /**
     * Get market sentiment (buy vs sell positions)
     */
    private function getMarketSentiment()
    {
        $positions = Position::select('symbol', 'type', DB::raw('COUNT(*) as count'))
            ->where('is_open', true)
            ->groupBy('symbol', 'type')
            ->get();
        
        $sentiment = [];
        
        foreach ($positions as $position) {
            if (!isset($sentiment[$position->symbol])) {
                $sentiment[$position->symbol] = ['buy' => 0, 'sell' => 0];
            }
            $sentiment[$position->symbol][$position->type] = $position->count;
        }
        
        // Calculate sentiment percentage
        $result = [];
        foreach ($sentiment as $symbol => $data) {
            $total = $data['buy'] + $data['sell'];
            if ($total > 5) { // Only show symbols with significant activity
                $result[] = [
                    'symbol' => $symbol,
                    'buy_percent' => round(($data['buy'] / $total) * 100, 1),
                    'sell_percent' => round(($data['sell'] / $total) * 100, 1),
                    'total' => $total,
                ];
            }
        }
        
        // Sort by total positions
        usort($result, function($a, $b) {
            return $b['total'] - $a['total'];
        });
        
        return array_slice($result, 0, 10);
    }
    
    /**
     * Get top performing symbols (by profit)
     */
    private function getTopPerformers()
    {
        return Deal::select('symbol', DB::raw('SUM(profit) as total_profit'), DB::raw('COUNT(*) as trades'))
            ->whereNotNull('symbol')           // ADD THIS
            ->where('symbol', '!=', '')        // ADD THIS
            ->where('symbol', '!=', 'UNKNOWN') // ADD THIS
            ->whereDate('time', '>=', now()->subDays(7))
            ->whereIn('entry', ['out', 'inout'])
            ->groupBy('symbol')
            ->orderBy('total_profit', 'desc')
            ->limit(10)
            ->get()
            ->map(function($item) {
                return [
                    'symbol' => $item->symbol,
                    'profit' => round($item->total_profit, 2),
                    'trades' => $item->trades,
                    'avg_profit' => round($item->total_profit / $item->trades, 2),
                ];
            });
    }
}
