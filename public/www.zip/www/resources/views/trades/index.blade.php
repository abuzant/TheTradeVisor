<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('My Trades') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <!-- Filters -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6">
                    <form method="GET" action="{{ route('trades.index') }}" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <input type="text" name="search" placeholder="Search symbol..." 
                               value="{{ request('search') }}"
                               class="rounded-md border-gray-300 shadow-sm">
                        
                        <select name="type" class="rounded-md border-gray-300 shadow-sm">
                            <option value="">All Types</option>
                            <option value="buy" {{ request('type') == 'buy' ? 'selected' : '' }}>Buy</option>
                            <option value="sell" {{ request('type') == 'sell' ? 'selected' : '' }}>Sell</option>
                        </select>
                        
                        <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                            Filter
                        </button>
                        <a href="{{ route('trades.index') }}" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 text-center">
                            Clear
                        </a>
                    </form>
                </div>
            </div>

            <!-- Trades Table -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Account</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Symbol</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Volume</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Profit</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @forelse($deals as $deal)
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {{ $deal->time ? $deal->time->format('Y-m-d H:i') : 'N/A' }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {{ $deal->tradingAccount->broker_name ?? 'N/A' }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                            <a href="{{ route('trades.symbol', $deal->normalized_symbol) }}" 
                                               class="text-indigo-600 hover:text-indigo-900"
                                               title="Raw: {{ $deal->symbol }}">
                                                {{ $deal->normalized_symbol }}
                                            </a>
                                            @if($deal->symbol !== $deal->normalized_symbol)
                                                <span class="text-xs text-gray-400 ml-1">({{ $deal->symbol }})</span>
                                            @endif
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                {{ str_contains(strtolower($deal->type), 'buy') ? 'bg-green-100 text-green-800' : 
                                                   (str_contains(strtolower($deal->type), 'sell') ? 'bg-red-100 text-red-800' : 
                                                   'bg-gray-100 text-gray-800') }}">
                                                {{ strtoupper($deal->type) }}
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {{ number_format($deal->volume, 2) }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {{ number_format($deal->price, 5) }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium {{ $deal->profit >= 0 ? 'text-green-600' : 'text-red-600' }}">
                                            {{ $deal->tradingAccount->account_currency }} {{ number_format($deal->profit, 2) }}
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="7" class="px-6 py-4 text-center text-gray-500">
                                            No trades found.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="mt-4">
                        {{ $deals->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>

</x-app-layout>
