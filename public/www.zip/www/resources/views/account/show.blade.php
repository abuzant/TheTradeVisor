<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ $account->broker_name }} - {{ $account->account_number ?? 'Account Details' }}
            </h2>
            <a href="{{ route('dashboard') }}" class="text-sm text-indigo-600 hover:text-indigo-900">
                ← Back to Dashboard
            </a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            
            {{-- Account Overview Cards --}}
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                
                {{-- Balance --}}
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <div class="text-sm font-medium text-gray-500 mb-1">Balance</div>
                        <div class="text-2xl font-bold text-gray-900">{{ $account->account_currency }} {{ number_format($account->balance, 2) }}</div>
                        <div class="text-xs text-gray-500 mt-1">{{ $account->account_currency }}</div>
                    </div>
                </div>

                {{-- Equity --}}
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <div class="text-sm font-medium text-gray-500 mb-1">Equity</div>
                        <div class="text-2xl font-bold text-gray-900">{{ $account->account_currency }} {{ number_format($account->equity, 2) }}</div>
                        <div class="text-xs text-gray-500 mt-1">Leverage: 1:{{ $account->leverage }}</div>
                    </div>
                </div>

                {{-- Profit --}}
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <div class="text-sm font-medium text-gray-500 mb-1">Current P&L</div>
                        <div class="text-2xl font-bold {{ $account->profit >= 0 ? 'text-green-600' : 'text-red-600' }}">
                            {{ $account->account_currency }} {{ number_format($account->profit, 2) }}
                        </div>
                        <div class="text-xs text-gray-500 mt-1">Open positions</div>
                    </div>
                </div>

                {{-- Margin Level --}}
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <div class="text-sm font-medium text-gray-500 mb-1">Margin Level</div>
                        <div class="text-2xl font-bold text-gray-900">
                            {{ $account->margin_level ? number_format($account->margin_level, 2) . '%' : 'N/A' }}
                        </div>
                        <div class="text-xs text-gray-500 mt-1">Free: ${{ number_format($account->free_margin, 2) }}</div>
                    </div>
                </div>

            </div>

            {{-- Trading Statistics --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-6">Trading Statistics (Last 30 Days)</h3>
                    
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
                        <div>
                            <div class="text-3xl font-bold text-gray-900">{{ $stats['total_trades'] }}</div>
                            <div class="text-sm text-gray-500">Total Trades</div>
                        </div>
                        <div>
                            <div class="text-3xl font-bold text-green-600">{{ $stats['winning_trades'] }}</div>
                            <div class="text-sm text-gray-500">Winning Trades</div>
                        </div>
                        <div>
                            <div class="text-3xl font-bold text-red-600">{{ $stats['losing_trades'] }}</div>
                            <div class="text-sm text-gray-500">Losing Trades</div>
                        </div>
                        <div>
                            <div class="text-3xl font-bold text-indigo-600">{{ $stats['win_rate'] }}%</div>
                            <div class="text-sm text-gray-500">Win Rate</div>
                        </div>
                    </div>

                    <div class="mt-6 pt-6 border-t border-gray-200 grid grid-cols-2 md:grid-cols-3 gap-6">
                        <div>
                            <div class="text-2xl font-bold {{ $stats['total_profit'] >= 0 ? 'text-green-600' : 'text-red-600' }}">
                                {{ $account->account_currency }} {{ number_format($stats['total_profit'], 2) }}
                            </div>
                            <div class="text-sm text-gray-500">Total P&L</div>
                        </div>
                        <div>
                            <div class="text-2xl font-bold text-gray-900">{{ $account->account_currency }} {{ number_format($stats['avg_profit'], 2) }}</div>
                            <div class="text-sm text-gray-500">Avg per Trade</div>
                        </div>
                        <div>
                            <div class="text-2xl font-bold text-gray-900">{{ $stats['most_traded_symbol'] }}</div>
                            <div class="text-sm text-gray-500">Most Traded</div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Charts Row --}}
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {{-- Equity Curve Chart --}}
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Equity Curve (Last 30 Days)</h3>
                        <div class="h-64">
                            <canvas id="equityChart"></canvas>
                        </div>
                    </div>
                </div>

                {{-- Symbol Distribution --}}
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Trading by Symbol</h3>
                        <div class="h-64">
                            <canvas id="symbolChart"></canvas>
                        </div>
                    </div>
                </div>

            </div>

            {{-- Trading Hours Heatmap --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Trading Activity by Hour</h3>
                    <div class="h-48">
                        <canvas id="hoursChart"></canvas>
                    </div>
                </div>
            </div>

            {{-- Open Positions --}}
            @if($account->openPositions->isNotEmpty())
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Open Positions</h3>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Symbol</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Volume</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Open Price</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Current</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">S/L</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">T/P</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Profit</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Opened</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach($account->openPositions as $position)
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">

					<a href="{{ route('trades.symbol', $position->normalized_symbol) }}"
                                           class="text-indigo-600 hover:text-indigo-900" title="({{ $position->symbol }})"
                                           title="Raw: {{ $position->symbol }}">
                                           {{ $position->normalized_symbol }}
                                         </a>
				    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full {{ $position->type == 'buy' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                                            {{ strtoupper($position->type) }}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $position->volume }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $position->open_price }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $position->current_price }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $position->sl ?? '-' }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $position->tp ?? '-' }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium {{ $position->profit >= 0 ? 'text-green-600' : 'text-red-600' }}">
                                        {{ $account->account_currency }} {{ number_format($position->profit, 2) }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $position->open_time->diffForHumans() }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            @endif

            {{-- Pending Orders --}}
            @if($account->activeOrders->isNotEmpty())
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Pending Orders</h3>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Symbol</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Volume</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">S/L</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">T/P</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Expiration</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Created</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach($account->activeOrders as $order)
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{{ $order->normalized_symbol }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                            {{ strtoupper(str_replace('_', ' ', $order->type)) }}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $order->volume_current }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $order->price_open }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $order->sl ?? '-' }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $order->tp ?? '-' }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {{ $order->expiration ? $order->expiration->format('M d, H:i') : 'No expiry' }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $order->time_setup->diffForHumans() }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            @endif

            {{-- Trading History --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Recent Trades</h3>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Symbol</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Entry</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Volume</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Profit</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Reason</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach($deals as $deal)
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {{ $deal->time->format('M d, H:i') }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{{ $deal->normalized_symbol }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full {{ $deal->type == 'buy' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                                            {{ strtoupper($deal->type) }}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ strtoupper($deal->entry) }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $deal->volume }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $deal->price }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium {{ $deal->profit >= 0 ? 'text-green-600' : 'text-red-600' }}">
                                        {{ $account->account_currency }} {{ number_format($deal->profit, 2) }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ strtoupper($deal->reason) }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-4">
                        {{ $deals->links() }}
                    </div>
                </div>
            </div>

        </div>
    </div>

    {{-- Chart.js Scripts --}}
    @push('scripts')
    <script>
        // Equity Curve Chart
        const equityCtx = document.getElementById('equityChart').getContext('2d');
        const equityChart = new Chart(equityCtx, {
            type: 'line',
            data: {
                labels: {!! json_encode($chartData['equity']['labels']) !!},
                datasets: [{
                    label: 'Equity',
                    data: {!! json_encode($chartData['equity']['data']) !!},
                    borderColor: 'rgb(79, 70, 229)',
                    backgroundColor: 'rgba(79, 70, 229, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });

        // Symbol Distribution Chart
        const symbolCtx = document.getElementById('symbolChart').getContext('2d');
        const symbolChart = new Chart(symbolCtx, {
            type: 'doughnut',
            data: {
                labels: {!! json_encode($chartData['symbols']['labels']) !!},
                datasets: [{
                    data: {!! json_encode($chartData['symbols']['data']) !!},
                    backgroundColor: [
                        'rgb(79, 70, 229)',
                        'rgb(16, 185, 129)',
                        'rgb(245, 158, 11)',
                        'rgb(239, 68, 68)',
                        'rgb(139, 92, 246)',
                        'rgb(236, 72, 153)'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                }
            }
        });

        // Trading Hours Chart
        const hoursCtx = document.getElementById('hoursChart').getContext('2d');
        const hoursChart = new Chart(hoursCtx, {
            type: 'bar',
            data: {
                labels: {!! json_encode($chartData['hours']['labels']) !!},
                datasets: [{
                    label: 'Trades',
                    data: {!! json_encode($chartData['hours']['data']) !!},
                    backgroundColor: 'rgba(79, 70, 229, 0.8)',
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
    </script>
    @endpush
</x-app-layout>
