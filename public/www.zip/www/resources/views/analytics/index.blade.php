<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Global Trading Analytics') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            
            {{-- Info Banner --}}
            <div class="bg-blue-50 border-l-4 border-blue-400 p-4">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-blue-700">
                            <strong>Global Analytics:</strong> Real-time insights from thousands of traders worldwide. All data is anonymized and aggregated.
                        </p>
                    </div>
                </div>
            </div>

            {{-- Overview Stats --}}
            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
                
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-4">
                        <div class="text-xs font-medium text-gray-500 mb-1">Active Traders</div>
                        <div class="text-2xl font-bold text-indigo-600">{{ number_format($analytics['overview']['total_traders']) }}</div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-4">
                        <div class="text-xs font-medium text-gray-500 mb-1">Accounts</div>
                        <div class="text-2xl font-bold text-green-600">{{ number_format($analytics['overview']['active_accounts']) }}</div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-4">
                        <div class="text-xs font-medium text-gray-500 mb-1">Brokers</div>
                        <div class="text-2xl font-bold text-purple-600">{{ $analytics['overview']['total_brokers'] }}</div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-4">
                        <div class="text-xs font-medium text-gray-500 mb-1">Countries</div>
                        <div class="text-2xl font-bold text-yellow-600">{{ $analytics['overview']['countries'] }}</div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-4">
                        <div class="text-xs font-medium text-gray-500 mb-1">Open Positions</div>
                        <div class="text-2xl font-bold text-orange-600">{{ number_format($analytics['overview']['open_positions']) }}</div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-4">
                        <div class="text-xs font-medium text-gray-500 mb-1">Trades Today</div>
                        <div class="text-2xl font-bold text-red-600">{{ number_format($analytics['overview']['trades_today']) }}</div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-4">
                        <div class="text-xs font-medium text-gray-500 mb-1">Volume Today</div>
                        <div class="text-2xl font-bold text-blue-600">{{ number_format($analytics['overview']['total_volume_today'], 1) }}</div>
                    </div>
                </div>

            </div>

            {{-- Charts Row 1 --}}
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {{-- Popular Pairs --}}
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Most Traded Pairs (7 Days)</h3>
                        <div class="space-y-3">
                            @foreach($analytics['popular_pairs'] as $pair)
                            <div class="flex items-center justify-between">
                                <div class="flex items-center space-x-3">
                                    <span class="text-sm font-semibold text-gray-900">{{ $pair['symbol'] }}</span>
                                    <span class="text-xs text-gray-500">{{ number_format($pair['trades']) }} trades</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <span class="text-sm text-gray-600">Vol: {{ number_format($pair['volume'], 1) }}</span>
                                    <div class="w-24 bg-gray-200 rounded-full h-2">
                                        <div class="bg-indigo-600 h-2 rounded-full" style="width: {{ min(100, ($pair['trades'] / $analytics['popular_pairs']->first()['trades']) * 100) }}%"></div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>

                {{-- Market Sentiment --}}
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Market Sentiment (Open Positions)</h3>
                        <div class="space-y-3">
                            @foreach($analytics['sentiment'] as $item)
                            <div>
                                <div class="flex items-center justify-between mb-1">
                                    <span class="text-sm font-semibold text-gray-900">{{ $item['symbol'] }}</span>
                                    <span class="text-xs text-gray-500">{{ $item['total'] }} positions</span>
                                </div>
                                <div class="flex h-4 rounded-full overflow-hidden">
                                    <div class="bg-green-500 flex items-center justify-center text-xs text-white font-semibold" style="width: {{ $item['buy_percent'] }}%">
                                        @if($item['buy_percent'] > 15)
                                            {{ $item['buy_percent'] }}%
                                        @endif
                                    </div>
                                    <div class="bg-red-500 flex items-center justify-center text-xs text-white font-semibold" style="width: {{ $item['sell_percent'] }}%">
                                        @if($item['sell_percent'] > 15)
                                            {{ $item['sell_percent'] }}%
                                        @endif
                                    </div>
                                </div>
                                <div class="flex justify-between text-xs text-gray-500 mt-1">
                                    <span>Buy {{ $item['buy_percent'] }}%</span>
                                    <span>Sell {{ $item['sell_percent'] }}%</span>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>

            </div>

            {{-- Trading Activity by Hour --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Trading Activity by Hour (UTC, Last 7 Days)</h3>
                    <div class="h-64">
                        <canvas id="hourlyChart"></canvas>
                    </div>
                </div>
            </div>

            {{-- Charts Row 2 --}}
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {{-- Regional Activity --}}
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Top Trading Countries</h3>
                        <div class="overflow-x-auto">
                            <table class="min-w-full">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Country</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Accounts</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Total Balance</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    @foreach($analytics['regional_activity'] as $region)
                                    <tr>
                                        <td class="px-4 py-2 text-sm font-medium text-gray-900">{{ $region['country'] }}</td>
                                        <td class="px-4 py-2 text-sm text-gray-500">{{ number_format($region['accounts']) }}</td>
                                        <td class="px-4 py-2 text-sm text-gray-900">${{ number_format($region['balance'], 0) }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                {{-- Top Performing Pairs --}}
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Top Performing Pairs (7 Days)</h3>
                        <div class="overflow-x-auto">
                            <table class="min-w-full">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Symbol</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Total P&L</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Trades</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Avg</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    @foreach($analytics['top_performers'] as $performer)
                                    <tr>
                                        <td class="px-4 py-2 text-sm font-medium text-gray-900">{{ $performer['symbol'] }}</td>
                                        <td class="px-4 py-2 text-sm font-semibold {{ $performer['profit'] >= 0 ? 'text-green-600' : 'text-red-600' }}">
                                            ${{ number_format($performer['profit'], 2) }}
                                        </td>
                                        <td class="px-4 py-2 text-sm text-gray-500">{{ number_format($performer['trades']) }}</td>
                                        <td class="px-4 py-2 text-sm text-gray-600">${{ number_format($performer['avg_profit'], 2) }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>

            {{-- Broker Distribution --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Broker Distribution</h3>
                    <div class="h-64">
                        <canvas id="brokerChart"></canvas>
                    </div>
                </div>
            </div>

        </div>
    </div>

    @push('scripts')
    <script>
        // Hourly Activity Chart
        const hourlyCtx = document.getElementById('hourlyChart').getContext('2d');
        new Chart(hourlyCtx, {
            type: 'bar',
            data: {
                labels: {!! json_encode(array_column($analytics['trading_by_hour'], 'hour')) !!},
                datasets: [{
                    label: 'Trades',
                    data: {!! json_encode(array_column($analytics['trading_by_hour'], 'trades')) !!},
                    backgroundColor: 'rgba(79, 70, 229, 0.8)',
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });

        // Broker Distribution Chart
        const brokerCtx = document.getElementById('brokerChart').getContext('2d');
        new Chart(brokerCtx, {
            type: 'doughnut',
            data: {
                labels: {!! json_encode($analytics['broker_distribution']->pluck('broker_name')) !!},
                datasets: [{
                    data: {!! json_encode($analytics['broker_distribution']->pluck('accounts')) !!},
                    backgroundColor: [
                        'rgb(79, 70, 229)',
                        'rgb(16, 185, 129)',
                        'rgb(245, 158, 11)',
                        'rgb(239, 68, 68)',
                        'rgb(139, 92, 246)',
                        'rgb(236, 72, 153)',
                        'rgb(59, 130, 246)',
                        'rgb(34, 197, 94)'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                }
            }
        });
    </script>
    @endpush
</x-app-layout>
