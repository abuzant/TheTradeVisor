<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Admin - All Trades') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            @if(session('success'))
                <div class="mb-6 bg-green-50 border-l-4 border-green-400 p-4">
                    <p class="text-sm text-green-700">{{ session('success') }}</p>
                </div>
            @endif

            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <div class="text-sm text-gray-600">Total Trades</div>
                    <div class="text-3xl font-bold text-gray-900">{{ number_format($stats['total']) }}</div>
                </div>
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <div class="text-sm text-gray-600">Today</div>
                    <div class="text-3xl font-bold text-blue-600">{{ number_format($stats['today']) }}</div>
                </div>
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <div class="text-sm text-gray-600">This Week</div>
                    <div class="text-3xl font-bold text-indigo-600">{{ number_format($stats['week']) }}</div>
                </div>
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <div class="text-sm text-gray-600">Active Users</div>
                    <div class="text-3xl font-bold text-green-600">{{ number_format($stats['active_users']) }}</div>
                </div>
            </div>

            <!-- Totals Summary -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-4">Filtered Results Summary</h3>
                    <div class="grid grid-cols-2 md:grid-cols-6 gap-4">
                        <div>
                            <div class="text-xs text-gray-600">Trades</div>
                            <div class="text-lg font-bold">{{ number_format($totals['tradeCount']) }}</div>
                        </div>
                        <div>
                            <div class="text-xs text-gray-600">Total Volume</div>
                            <div class="text-lg font-bold">{{ number_format($totals['totalVolume'], 2) }}</div>
                        </div>
                        <div>
                            <div class="text-xs text-gray-600">Total Profit</div>
                            <div class="text-lg font-bold {{ $totals['totalProfit'] >= 0 ? 'text-green-600' : 'text-red-600' }}">
                                ${{ number_format($totals['totalProfit'], 2) }}
                            </div>
                        </div>
                        <div>
                            <div class="text-xs text-gray-600">Commission</div>
                            <div class="text-lg font-bold text-gray-700">${{ number_format($totals['totalCommission'], 2) }}</div>
                        </div>
                        <div>
                            <div class="text-xs text-gray-600">Fees</div>
                            <div class="text-lg font-bold text-gray-700">${{ number_format($totals['totalFees'], 2) }}</div>
                        </div>
                        <div>
                            <div class="text-xs text-gray-600">Swap</div>
                            <div class="text-lg font-bold {{ $totals['totalSwap'] >= 0 ? 'text-green-600' : 'text-red-600' }}">
                                ${{ number_format($totals['totalSwap'], 2) }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filters -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6">
                    <form method="GET" action="{{ route('admin.trades.index') }}">
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                            <input type="text" name="search" placeholder="Search symbol, ticket, user..." 
                                   value="{{ $search }}"
                                   class="rounded-md border-gray-300 shadow-sm">
                            
                            <select name="user_id" class="rounded-md border-gray-300 shadow-sm">
                                <option value="">All Users</option>
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}" {{ $userId == $user->id ? 'selected' : '' }}>
                                        {{ $user->name }}
                                    </option>
                                @endforeach
                            </select>
                            
                            <select name="symbol" class="rounded-md border-gray-300 shadow-sm">
                                <option value="">All Symbols</option>
                                @foreach($symbols as $sym)
                                    <option value="{{ $sym }}" {{ $symbol == $sym ? 'selected' : '' }}>
                                        {{ $sym }}
                                    </option>
                                @endforeach
                            </select>
                            
                            <select name="type" class="rounded-md border-gray-300 shadow-sm">
                                <option value="all" {{ $type == 'all' ? 'selected' : '' }}>All Types</option>
                                <option value="buy" {{ $type == 'buy' ? 'selected' : '' }}>Buy</option>
                                <option value="sell" {{ $type == 'sell' ? 'selected' : '' }}>Sell</option>
                                <option value="trades" {{ $type == 'trades' ? 'selected' : '' }}>Trades Only</option>
                                <option value="cashier" {{ $type == 'cashier' ? 'selected' : '' }}>Deposits/Withdrawals</option>
                                <option value="fees" {{ $type == 'fees' ? 'selected' : '' }}>Fees</option>
                                <option value="swaps" {{ $type == 'swaps' ? 'selected' : '' }}>Swaps</option>
                            </select>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                            <input type="date" name="date_from" value="{{ $dateFrom }}" 
                                   class="rounded-md border-gray-300 shadow-sm" placeholder="Date From">
                            
                            <input type="date" name="date_to" value="{{ $dateTo }}" 
                                   class="rounded-md border-gray-300 shadow-sm" placeholder="Date To">
                            
                            <select name="per_page" class="rounded-md border-gray-300 shadow-sm">
                                <option value="25" {{ $perPage == 25 ? 'selected' : '' }}>25 per page</option>
                                <option value="50" {{ $perPage == 50 ? 'selected' : '' }}>50 per page</option>
                                <option value="100" {{ $perPage == 100 ? 'selected' : '' }}>100 per page</option>
                                <option value="200" {{ $perPage == 200 ? 'selected' : '' }}>200 per page</option>
                            </select>
                            
                            <div class="flex gap-2">
                                <button type="submit" class="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                                    Filter
                                </button>
                                <a href="{{ route('admin.trades.index') }}" class="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 text-center">
                                    Clear
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Trades Table -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ticket</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Account</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Symbol</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Volume</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Profit</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @forelse($deals as $deal)
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {{ $deal->ticket }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {{ $deal->time ? $deal->time->format('Y-m-d H:i') : 'N/A' }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                                            @if($deal->tradingAccount && $deal->tradingAccount->user)
                                                <a href="{{ route('admin.users.show', $deal->tradingAccount->user_id) }}" class="text-indigo-600 hover:text-indigo-900">
                                                    {{ $deal->tradingAccount->user->name }}
                                                </a>
                                            @else
                                                <span class="text-gray-400">N/A</span>
                                            @endif
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {{ $deal->tradingAccount->broker_name ?? 'N/A' }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                            <a href="{{ route('admin.trades.index', ['symbol' => $deal->normalized_symbol]) }}"  title="Raw: {{ $deal->symbol }}"
                                               class="text-indigo-600 hover:text-indigo-900">
                                                {{ $deal->normalized_symbol }}
                                            </a>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                {{ str_contains(strtolower($deal->type), 'buy') ? 'bg-green-100 text-green-800' : 
                                                   (str_contains(strtolower($deal->type), 'sell') ? 'bg-red-100 text-red-800' : 
                                                   'bg-gray-100 text-gray-800') }}">
                                                {{ strtoupper($deal->type) }}
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {{ number_format($deal->volume, 2) }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {{ number_format($deal->price, 5) }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium {{ $deal->profit >= 0 ? 'text-green-600' : 'text-red-600' }}">
                                            ${{ number_format($deal->profit, 2) }}
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="9" class="px-6 py-4 text-center text-gray-500">
                                            No trades found.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="mt-4">
                        {{ $deals->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
